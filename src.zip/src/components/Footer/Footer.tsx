const Footer = () => {
	return (
		<footer className="pl-[230px] px-5 py-10 absolute bottom-0">
			<h1>
				Lorem ipsum dolor sit amet consectetur adipisicing elit.
				Voluptatem incidunt inventore, quidem cumque veritatis
				sint dolores reprehenderit neque accusamus! Consequatur
				maiores mollitia aliquid numquam sapiente earum unde,
				consequuntur fuga quidem. Lorem ipsum dolor sit amet
				consectetur, adipisicing elit. Hic quod culpa eius optio
				possimus, ea neque modi pariatur, dolores fuga autem error
				consectetur aperiam assumenda laborum consequuntur
				sapiente ex enim?
			</h1>
		</footer>
	);
};

export default Footer;
